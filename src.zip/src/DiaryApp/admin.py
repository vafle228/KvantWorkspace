from django.contrib import admin
from .models import *


admin.site.register(KvantHomeTask)
admin.site.register(KvantLesson)
admin.site.register(KvantTaskBase)
admin.site.register(KvantTaskMark)
admin.site.register(KvantHomeWork)
