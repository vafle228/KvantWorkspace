from django.views import generic


class NotificationDeleteView(generic.View):
    def post(self, request, *args, **kwargs):
        pass