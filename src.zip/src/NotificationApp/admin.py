from django.contrib import admin
from .models import KvantNotification


admin.site.register(KvantNotification)
