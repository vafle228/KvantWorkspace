from django.apps import AppConfig


class NotificationAppConfig(AppConfig):
    name = 'NotificationApp'
