from django.contrib import admin
from .models import FileStorage


admin.site.register(FileStorage)
