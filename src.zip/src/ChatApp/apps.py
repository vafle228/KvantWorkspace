from django.apps import AppConfig


class ChatAppConfig(AppConfig):
    name = 'ChatApp'
