# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = '6q*nolmjv+0my(*vt_pvr)j6ltsp=!=%b1p1-0rgufnl_u#_y#'
AWS_ACCESS_KEY_ID = 'AKIAZTAFQGAI3TCYD4PL'  # Id (дается при создании бакета)
AWS_SECRET_ACCESS_KEY = 'NnY3zfGq3nblfc925wVcEn0ifkhQgR8yyaWrYPov'  # Key (дается при создании бакета)