from django.apps import AppConfig


class JournalAppConfig(AppConfig):
    name = 'JournalApp'
