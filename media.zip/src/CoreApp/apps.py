from django.apps import AppConfig


class CoreAppConfig(AppConfig):
    name = 'CoreApp'
